package tarea1.tarea1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarea1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
